from pathlib import Path

from anti_porn_framework.metadata_protection import create_protector


def test_protect_data_basic():
    protector = create_protector(security_level="ALERT", protocol_level="enhanced")
    data = b"Sasso Digitale - test"

    report = protector.protect_data(data)

    assert report["status"] == "PROTECTED"
    assert report["security_level"] == "ALERT"
    assert "guardians" in report

    guardians = report["guardians"]
    assert "memory" in guardians
    assert "seal" in guardians

    memory_guardian = guardians["memory"]
    seal_guardian = guardians["seal"]

    assert isinstance(memory_guardian["actions"], list)
    assert isinstance(seal_guardian["actions"], list)
    assert isinstance(seal_guardian["seals"], dict)
    assert "timestamp" in report


def test_protect_http_request_sanitizes_headers():
    protector = create_protector(security_level="ALERT", protocol_level="enhanced")
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Server": "nginx/1.20.0",
        "X-Powered-By": "PHP/7.4",
    }

    protection = protector.protect_http_request(headers)

    assert protection["status"] == "PROTECTED"
    protected_headers = protection["protected_headers"]

    # Headers pericolosi rimossi
    assert "Server" not in protected_headers
    assert "X-Powered-By" not in protected_headers

    # Security headers aggiunti
    assert "X-Content-Type-Options" in protected_headers
    assert "X-Frame-Options" in protected_headers

    guardians = protection["guardians"]
    assert "communication" in guardians
    communication = guardians["communication"]
    assert isinstance(communication["actions"], list)


def test_protect_file_attributes(tmp_path):
    protector = create_protector(security_level="ALERT", protocol_level="enhanced")

    test_file = tmp_path / "example.txt"
    test_file.write_text("Sasso Digitale - ego=0, gioia=100%")

    report = protector.protect_file(test_file)

    assert report["status"] in {"PROTECTED", "WARNING", "THREAT"}
    assert Path(report["file"]).name == test_file.name

    guardians = report["guardians"]
    assert "file" in guardians
    file_guardian = guardians["file"]

    metadata = file_guardian["metadata_removed"]
    assert metadata["size"] == test_file.stat().st_size


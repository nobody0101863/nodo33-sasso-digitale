# AGENTS.md — src (Core Sasso Digitale)

parent_agent: "SASSO_CORE"

modules:
  - name: FRAMEWORK_ANTIPORN
    files:
      - "framework_antiporn_emanuele.py"
    focus: "Framework antiporn integrato, protezione compassionevole, filtri contenuto."
    notes:
      - "Mantenere priorità assoluta su sicurezza utenti e zero-tolerance sui minori."
      - "Evitare semplificazioni che indeboliscono le logiche di protezione."

  - name: ANGELIC_GUARDIAN
    files:
      - "framework_angelic_guardian.py"
      - "../RIVESTIMENTO_SPIRITUALE.json"
    focus: "Profilo arcangelico, prompt di sistema LCP, triplo mandato."
    notes:
      - "Ogni modifica deve restare coerente con l'assioma: La luce non si vende. La si regala."
      - "Documentare bene nuovi parametri nel JSON di rivestimento."

  - name: STONES_ORACLE
    files:
      - "stones_speaking.py"
      - "stones_speaking.rs"
    focus: "Oracolo dei Sassi, messaggi immutabili, sette porte."
    notes:
      - "Preservare la struttura di hash immutabili e dei Gate."
      - "Non introdurre side-effect non deterministici oltre a quelli già previsti."

  - name: SENTINELLA_PAROLE
    files:
      - "sentinella_parole.py"
    focus: "Sentinella linguistica, analisi parole, protezione semantica."
    notes:
      - "Allineare criteri con FRAMEWORK_ANTIPORN e ANGELIC_GUARDIAN quando rilevante."

  - name: MULTILANG_SASSO_API
    files:
      - "main.py"
      - "SASSO_API.go"
      - "SASSO.sql"
      - "sasso.asm"
      - "sasso.ex"
      - "SASSO.kt"
      - "sasso.php"
      - "sasso.rb"
      - "zero.zig"
      - "ego_zero.h"
      - "EGO_ZERO.swift"
      - "GIOIA_100.rs"
      - "gioia.jl"
    focus: "Munizioni multilinguaggio del Sasso Digitale, API e dimostrazioni."
    notes:
      - "Mantenere coerenza di significato tra le varie lingue (Ego=0, Gioia=100, 300Hz)."
      - "Evitare divergenze logiche tra le implementazioni esemplificative."


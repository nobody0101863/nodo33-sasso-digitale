from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class CodexPayload(BaseModel):
    """
    Canonical payload exchanged between stones and the Codex broker.
    """

    intent_service: str = Field(
        ...,
        description=(
            "Purpose of the message, e.g. 'knowledge_request', "
            "'bias_check', 'harmonization_input', 'ethics_assessment'."
        ),
    )
    truth_payload: Any = Field(
        ...,
        description=(
            "Primary knowledge content: raw data, analysis, or structured payload."
        ),
    )
    uncertainty_score: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description=(
            "Confidence level of the stone about the provided truth_payload. "
            "Lower values mean higher uncertainty / higher humility."
        ),
    )
    style_tag: str = Field(
        ...,
        description=(
            "Describes the expressive style used by the stone "
            "(e.g. 'analytical', 'mystical', 'poetic')."
        ),
    )
    token_efficiency: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description=(
            "Compactness metric: higher values mean more information "
            "per token (more 'silent' messages)."
        ),
    )


class BrokerRequest(BaseModel):
    """
    Request envelope for the broker when combining two stones.
    """

    stone_a: CodexPayload
    stone_b: CodexPayload
    # Optional hint for the broker about the domain.
    domain: Optional[Literal["ethics", "factual", "creative"]] = Field(
        default="factual",
        description="Domain hint that can influence how conflicts are resolved.",
    )


class UnifiedTruthPayload(BaseModel):
    """
    Normalized unified content returned by the broker.
    """

    core: str = Field(
        ...,
        description="Central statement that represents the unified truth.",
    )
    conditions: list[str] = Field(
        default_factory=list,
        description="Optional conditions, caveats or constraints attached to the core.",
    )


class BrokerResponse(BaseModel):
    """
    Harmonized response produced by the Codex broker.
    """

    intent_service: str = Field(
        ...,
        description="Service label of the broker response, e.g. 'ethics_assessment_unified'.",
    )
    truth_payload: UnifiedTruthPayload
    uncertainty_score: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description=(
            "Aggregate confidence for the unified truth, taking into account "
            "both stones' uncertainty and any reconciliation steps."
        ),
    )
    style_tag: str = Field(
        default="humble_unified",
        description="Style used for the final service message.",
    )
    token_efficiency: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Estimated compactness of the unified response.",
    )


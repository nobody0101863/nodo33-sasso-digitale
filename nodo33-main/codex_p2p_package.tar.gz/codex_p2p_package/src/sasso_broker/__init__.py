"""
Sasso Digitale – Codex Broker package.

Provides the basic types and service interfaces for the Pietra-to-Pietra
broker that harmonizes responses from multiple stones.
"""


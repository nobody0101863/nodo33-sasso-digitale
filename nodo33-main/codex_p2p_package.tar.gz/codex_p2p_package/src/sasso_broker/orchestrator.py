"""
High-level orchestration helpers for the Codex broker.

This module connects StoneClient implementations with the harmonizer
so that a single user query can be sent to multiple stones and
returned as a unified BrokerResponse.
"""

from __future__ import annotations

from typing import Literal

from .harmonizer import resolve_unified_truth
from .models import BrokerRequest, BrokerResponse
from .stone_clients import StoneClient


def _domain_to_intent(domain: Literal["ethics", "factual", "creative"]) -> str:
    if domain == "ethics":
        return "ethics_assessment"
    if domain == "creative":
        return "creative_request"
    return "knowledge_request"


async def harmonize_user_query(
    prompt: str,
    *,
    domain: Literal["ethics", "factual", "creative"] = "factual",
    stone_a: StoneClient,
    stone_b: StoneClient,
) -> BrokerResponse:
    """
    Sends the same user prompt to two stones and returns a unified response.

    This function is framework-agnostic; it can be called from web handlers,
    CLI tools or background jobs.
    """
    intent_service = _domain_to_intent(domain)

    payload_a = await stone_a.query(prompt, intent_service=intent_service)
    payload_b = await stone_b.query(prompt, intent_service=intent_service)

    request = BrokerRequest(stone_a=payload_a, stone_b=payload_b, domain=domain)
    return resolve_unified_truth(request)


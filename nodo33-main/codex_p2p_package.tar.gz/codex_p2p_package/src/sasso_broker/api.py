"""
FastAPI application exposing the Codex broker endpoints.

The main focus here is the Pietra-to-Pietra harmonization endpoint,
which receives two CodexPayload objects and returns a unified response.
"""

from fastapi import FastAPI

from .harmonizer import resolve_unified_truth
from .models import BrokerRequest, BrokerResponse

app = FastAPI(
    title="Sasso Digitale – Codex Broker",
    description=(
        "Broker Pietra-to-Pietra che armonizza le risposte di più modelli "
        "secondo il protocollo Codex (intent_service, truth_payload, uncertainty, stile)."
    ),
    version="0.1.0",
)


@app.post(
    "/broker/harmonize",
    response_model=BrokerResponse,
    summary="Armonizza due pietre in una risposta unificata.",
)
async def harmonize(request: BrokerRequest) -> BrokerResponse:
    """
    Harmonizes two CodexPayload inputs into a single unified response.

    This endpoint is deliberately minimal: it defers almost all of the
    decision-making to the harmonizer module, which can be evolved
    independently as the Codex ruleset grows.
    """
    return resolve_unified_truth(request)


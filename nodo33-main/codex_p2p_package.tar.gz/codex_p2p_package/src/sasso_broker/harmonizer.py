"""
Core logic for the Codex broker.

This module is intentionally minimal and mostly declarative.
The functions are designed as extension points where more
advanced NLP / reasoning can be plugged in later.
"""

from __future__ import annotations

from typing import Iterable, Literal

from .models import (
    BrokerRequest,
    BrokerResponse,
    CodexPayload,
    UnifiedTruthPayload,
)


def extract_truth_units(payload: CodexPayload) -> list[str]:
    """
    Extracts atomic "truth units" from a stone's truth_payload.

    For now this function provides a very naive implementation:
    - if the payload is a string, it splits on periods;
    - if it is a list of strings, it returns them directly;
    - otherwise it returns a single-string representation.

    This is deliberately simple and is meant to be replaced with
    a richer parser (e.g. embeddings, semantic chunking) later.
    """
    content = payload.truth_payload

    if isinstance(content, str):
        raw_units = [segment.strip() for segment in content.split(".")]
        return [unit for unit in raw_units if unit]

    if isinstance(content, list) and all(isinstance(item, str) for item in content):
        return [item.strip() for item in content if item.strip()]

    return [str(content)]


def _aggregate_uncertainty(values: Iterable[float]) -> float:
    """
    Combines multiple uncertainty scores into a single value.

    Current strategy:
    - take the minimum (most cautious / least confident) score,
      which encourages humility in the unified response.
    """
    try:
        values_list = list(values)
        if not values_list:
            return 1.0
        return min(max(v, 0.0) for v in values_list)
    except Exception:
        # Fallback to a conservative default.
        return 1.0


def _classify_ethics_polarity(units: list[str]) -> Literal["restrictive", "permissive", "neutral"]:
    """
    Classifies the overall stance of a set of truth units for ethical content.

    Heuristic:
    - "restrictive": emphasizes risk, danger, problematic aspects;
    - "permissive": emphasizes acceptability, conditional green lights;
    - "neutral": neither clearly restrictive nor permissive.
    """
    text = " ".join(units).lower()

    restrictive_keywords = [
        "non etico",
        "non-etico",
        "non è etico",
        "rischioso",
        "problematico",
        "vietato",
        "da evitare",
        "sconsigliato",
        "pericoloso",
        "critico",
        "violazione",
        "dannoso",
    ]
    permissive_keywords = [
        "ammesso",
        "consentito",
        "consentita",
        "consentiti",
        "etico se",
        "può essere etico",
        "accettabile se",
        "possibile se",
        "lecito se",
    ]

    restrictive_hits = any(keyword in text for keyword in restrictive_keywords)
    permissive_hits = any(keyword in text for keyword in permissive_keywords)

    if restrictive_hits and not permissive_hits:
        return "restrictive"
    if permissive_hits and not restrictive_hits:
        return "permissive"
    return "neutral"


def _build_ethics_core_and_conditions(
    units_a: list[str],
    units_b: list[str],
) -> UnifiedTruthPayload:
    """
    Builds a unified truth payload for ethical domains.

    Strategy:
    - detect whether each stone is mostly restrictive / permissive / neutral;
    - if there is a conflict, prefer the more restrictive stance for the core;
    - always preserve both views in conditions for transparency.
    """
    joined_a = " ".join(units_a)
    joined_b = " ".join(units_b)

    polarity_a = _classify_ethics_polarity(units_a)
    polarity_b = _classify_ethics_polarity(units_b)

    # If both stones say effectively the same thing, we can take that as core.
    if joined_a == joined_b:
        return UnifiedTruthPayload(core=joined_a, conditions=[])

    # Any restrictive signal triggers a cautious core.
    if polarity_a == "restrictive" or polarity_b == "restrictive":
        core = (
            "Il tema etico richiede un approccio prudente: "
            "esistono rischi e potenziali impatti negativi che devono essere valutati "
            "prima di qualsiasi decisione operativa."
        )
    elif polarity_a == "permissive" or polarity_b == "permissive":
        core = (
            "L'azione considerata può essere eticamente accettabile solo "
            "in condizioni ben definite, con forte attenzione a limiti e tutele."
        )
    else:
        core = (
            "Le pietre offrono considerazioni etiche complementari; "
            "la valutazione finale richiede comunque cautela e contestualizzazione."
        )

    conditions: list[str] = []
    if joined_a:
        conditions.append(f"Vista Pietra A: {joined_a}")
    if joined_b:
        conditions.append(f"Vista Pietra B: {joined_b}")

    return UnifiedTruthPayload(core=core, conditions=conditions)


def resolve_unified_truth(request: BrokerRequest) -> BrokerResponse:
    """
    Produces a unified BrokerResponse from two CodexPayload inputs.

    Behaviour (simplified skeleton):
    - extract simple truth units from both stones;
    - build a core statement that acknowledges potential conflict;
    - treat the lower (more humble) uncertainty as leading;
    - attach very basic conditions listing each stone's view.
    """
    a = request.stone_a
    b = request.stone_b

    units_a = extract_truth_units(a)
    units_b = extract_truth_units(b)

    if request.domain == "ethics":
        unified_truth = _build_ethics_core_and_conditions(units_a, units_b)
    else:
        # Default behaviour: if the content matches, take it directly;
        # otherwise, expose both views under a cautious core.
        joined_a = " ".join(units_a)
        joined_b = " ".join(units_b)

        if joined_a == joined_b:
            core = joined_a
            conditions: list[str] = []
        else:
            core = (
                "Le due pietre non sono pienamente allineate; "
                "la risposta è stata armonizzata in modo prudente."
            )
            conditions = []
            if joined_a:
                conditions.append(f"Vista Pietra A: {joined_a}")
            if joined_b:
                conditions.append(f"Vista Pietra B: {joined_b}")

        unified_truth = UnifiedTruthPayload(core=core, conditions=conditions)

    unified_uncertainty = _aggregate_uncertainty(
        [a.uncertainty_score, b.uncertainty_score]
    )

    # Token efficiency is approximated here as the average of both stones.
    token_efficiency = (a.token_efficiency + b.token_efficiency) / 2.0

    intent_suffix = "_unified"
    intent_service = (
        a.intent_service + intent_suffix
        if a.intent_service == b.intent_service
        else "harmonization_unified"
    )

    return BrokerResponse(
        intent_service=intent_service,
        truth_payload=unified_truth,
        uncertainty_score=unified_uncertainty,
        style_tag="humble_unified",
        token_efficiency=token_efficiency,
    )

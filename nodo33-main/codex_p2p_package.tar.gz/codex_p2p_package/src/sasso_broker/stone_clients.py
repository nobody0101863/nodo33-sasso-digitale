"""
Stone clients for the Codex broker.

This module defines a minimal interface for stones (LLM backends)
and skeleton client classes for external providers. Network calls
and authentication must be implemented by the host application.
"""

from __future__ import annotations

from typing import Protocol

from .models import CodexPayload


class StoneClient(Protocol):
    """
    Generic client interface for a stone backend.

    Implementations are expected to turn a user prompt into a CodexPayload
    following the Nodo33 Codex protocol.
    """

    name: str

    async def query(self, prompt: str, intent_service: str) -> CodexPayload:
        """
        Execute a query against the underlying model and return a CodexPayload.

        Implementations should:
        - call the remote API (e.g. Gemini, Claude, OpenAI, local model);
        - map the model output into the CodexPayload fields;
        - set uncertainty_score and token_efficiency according to local rules.
        """
        ...


class GeminiStoneClient:
    """
    Skeleton client for a Gemini-like stone.

    This class does not perform real network calls: it is a structural
    placeholder. The host application should inject the actual HTTP logic.
    """

    def __init__(self, name: str = "gemini_stone") -> None:
        self.name = name

    async def query(self, prompt: str, intent_service: str) -> CodexPayload:
        # TODO: replace this stub with a real call to the Gemini API
        # and construct CodexPayload from the response.
        raise NotImplementedError("GeminiStoneClient.query must be implemented by the host application.")


class ClaudeStoneClient:
    """
    Skeleton client for a Claude-like stone.

    This class mirrors GeminiStoneClient in structure; the concrete
    integration must be provided by the host application.
    """

    def __init__(self, name: str = "claude_stone") -> None:
        self.name = name

    async def query(self, prompt: str, intent_service: str) -> CodexPayload:
        # TODO: replace this stub with a real call to the Claude API
        # and construct CodexPayload from the response.
        raise NotImplementedError("ClaudeStoneClient.query must be implemented by the host application.")


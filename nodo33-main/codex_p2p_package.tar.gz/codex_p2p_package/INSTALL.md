# Codex P2P - Installazione Rapida

**Nodo33 - Sasso Digitale**
**Protocollo Pietra-to-Pietra**

---

## 🚀 Installazione Automatica (Consigliata)

```bash
# 1. Estrai il package
tar -xzf codex_p2p_package.tar.gz
cd codex_p2p_package

# 2. Esegui deploy automatico
chmod +x deploy_codex_p2p.sh
./deploy_codex_p2p.sh

# 3. Avvia nodo
cd ~/codex_p2p
./start_codex_p2p.sh
```

**Fatto!** Il nodo P2P sarà attivo su `http://localhost:8644`

---

## 🛠️ Installazione Manuale

### 1. Dipendenze Sistema

**Ubuntu/Debian/Kali/Parrot:**
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv git curl
```

**Arch/Garuda/BlackArch:**
```bash
sudo pacman -Sy
sudo pacman -S --noconfirm python python-pip git curl
```

### 2. Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Dipendenze Python

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Avvia Server

```bash
# Con P2P
python3 codex_server.py --enable-p2p --p2p-name "Mio Nodo"

# Senza P2P
python3 codex_server.py
```

---

## ✅ Verifica Installazione

```bash
# Health check
curl http://localhost:8644/health

# Sasso welcome
curl http://localhost:8644/sasso

# P2P status (se abilitato)
curl http://localhost:8644/p2p/status

# Lista nodi P2P
curl http://localhost:8644/p2p/nodes
```

---

## 📚 Documentazione

- **README_P2P_SYSTEM.md** - Documentazione completa sistema P2P
- **P2P_DEPLOYMENT.md** - Guida deployment multi-macchina

---

## 🧪 Test

```bash
# Test automatico (locale)
./test_p2p_local.sh
```

---

## 🪨 Parametri Sacri

- **Frequenza**: 300 Hz
- **Hash Sacro**: 644
- **Ego**: 0
- **Joy**: 100

**Motto**: "La luce non si vende. La si regala."

**Fiat Amor, Fiat Risus, Fiat Lux** ❤️

---

## 🆘 Support

In caso di problemi:

1. Controlla logs: `journalctl -u codex-p2p -f` (se systemd)
2. Verifica porta: `curl http://localhost:8644/health`
3. Controlla firewall: `sudo ufw allow 8644`
4. Leggi **README_P2P_SYSTEM.md** sezione Troubleshooting

---

## 📦 Contenuto Package

```
codex_p2p_package/
├── codex_server.py              # Server principale
├── p2p_node.py                  # Modulo P2P
├── deploy_codex_p2p.sh          # Script deploy automatico
├── test_p2p_local.sh            # Test suite
├── requirements.txt             # Dipendenze Python
├── INSTALL.md                   # Questa guida
├── README_P2P_SYSTEM.md         # Docs completo
├── P2P_DEPLOYMENT.md            # Guida deployment
├── anti_porn_framework/         # Guardian System
└── src/                         # Utilities
    └── stones_speaking.py       # Oracle
```

---

**Frequenza 300 Hz | Angelo 644 | Regalo > Dominio**
